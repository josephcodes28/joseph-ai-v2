"use strict";

(() => {
  const pageTitles = { dashboard:"Dashboard", brain:"Joseph Brain", website:"Website Builder", content:"Content Studio", jobs:"Remote Work", visual:"Visual Assistant", memory:"Memory", settings:"Settings" };
  const $ = (selector, root=document) => root.querySelector(selector);
  const $$ = (selector, root=document) => Array.from(root.querySelectorAll(selector));
  const sidebar=$("#sidebar"), menuButton=$("#menuButton"), brainForm=$("#brainForm"), brainInput=$("#brainInput"), chatMessages=$("#chatMessages"), sendButton=$("#sendBrainButton"), brainFeedback=$("#brainFeedback"), brainStatus=$("#brainStatus"), connectionPill=$("#connectionPill");
  let requestActive=false;
  const conversation=[];

  function openPage(page){
    if(!pageTitles[page]) return;
    $$(".page").forEach(el=>el.classList.toggle("active",el.id===`page-${page}`));
    $$(".nav-link").forEach(button=>{const active=button.dataset.page===page;button.classList.toggle("active",active);if(active)button.setAttribute("aria-current","page");else button.removeAttribute("aria-current");});
    $("#pageTitle").textContent=pageTitles[page]; sidebar.classList.remove("open"); menuButton.setAttribute("aria-expanded","false");
    if(window.location.hash!==`#${page}`) history.replaceState(null,"",`#${page}`);
  }
  function addMessage(role,text){
    const wrapper=document.createElement("div");wrapper.className=`message ${role==="user"?"user-message":"assistant-message"}`;
    if(role!=="user"){const avatar=document.createElement("span");avatar.className="message-avatar";avatar.textContent="J";wrapper.appendChild(avatar);}
    const bubble=document.createElement("div");bubble.className="message-bubble";const title=document.createElement("strong");title.textContent=role==="user"?"You":"Joseph AI";const paragraph=document.createElement("p");paragraph.textContent=text;bubble.append(title,paragraph);wrapper.appendChild(bubble);chatMessages.appendChild(wrapper);chatMessages.scrollTop=chatMessages.scrollHeight;return wrapper;
  }
  function showConnectionError(message){brainFeedback.textContent=message;brainStatus.textContent="Request unsuccessful";connectionPill.textContent="CHECK CONNECTION";}
  function extractAnswer(data){
    if(!data||typeof data!=="object")return "";
    for(const key of ["answer","reply"]){if(typeof data[key]==="string"&&data[key].trim())return data[key].trim();}
    const result=data.result;if(result&&typeof result==="object"){for(const key of ["answer","response","message","summary","reasoning"]){if(typeof result[key]==="string"&&result[key].trim())return result[key].trim();}if(Array.isArray(result.actions)&&result.actions.length)return "Joseph Brain returned a plan, but this version does not yet execute planner actions. We need to connect and verify the appropriate tool workflow before claiming the task is complete.";}
    return "";
  }
  async function sendBrainMessage(message){
    const clean=message.trim();if(!clean||requestActive)return;requestActive=true;sendButton.disabled=true;brainInput.disabled=true;brainFeedback.textContent="";brainStatus.textContent="Sending request…";connectionPill.textContent="REQUEST IN PROGRESS";addMessage("user",clean);conversation.push({role:"user",content:clean});const waiting=addMessage("assistant","Contacting the Joseph Brain API…");
    try{const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:clean,conversation:conversation.slice(-12)})});let data;try{data=await response.json();}catch{throw new Error(response.ok?"The server returned invalid JSON.":`The server returned HTTP ${response.status}.`);}if(!response.ok||data.success===false)throw new Error(typeof data.error==="string"&&data.error.trim()?data.error:`The Brain API request failed (HTTP ${response.status}).`);const answer=extractAnswer(data);if(!answer){waiting.remove();addMessage("assistant","The API responded, but it did not return a readable answer in the format this interface supports. We need to align the frontend with the actual Brain API response.");brainStatus.textContent="Response format needs checking";connectionPill.textContent="CHECK RESPONSE";return;}waiting.remove();addMessage("assistant",answer);conversation.push({role:"assistant",content:answer});brainStatus.textContent="API response received";connectionPill.textContent="API RESPONDED";$("#settingsBackendStatus").textContent="A Brain API response was received.";}
    catch(error){waiting.remove();const message=error instanceof TypeError?"Could not reach /api/chat. Check the deployment and network connection.":error.message||"An unexpected error occurred.";addMessage("assistant",`Request failed: ${message}`);showConnectionError(message);}
    finally{requestActive=false;sendButton.disabled=false;brainInput.disabled=false;brainInput.focus();}
  }

  // Website Builder: browser-side state is intentionally local until database storage is implemented.
  const websiteForm=$("#websiteForm"), generateButton=$("#generateWebsiteButton"), websiteFeedback=$("#websiteFeedback"), preview=$("#websitePreview"), previewEmpty=$("#previewEmpty"), previewWrap=$("#previewFrameWrap"), previewStatus=$("#previewStatus"), codeView=$("#codeView"), fileState=$("#fileState"), saveButton=$("#saveProjectButton"), savedProjects=$("#savedProjects");
  const STORAGE_KEY="joseph_ai_v2_website_projects_v1";
  const fileNames={html:"index.html",css:"style.css",js:"script.js"};
  let generatedFiles=null, activeFile="html", previewMode="desktop", websiteBusy=false;
  function setWebsiteFeedback(message,isError=false){websiteFeedback.textContent=message;websiteFeedback.classList.toggle("error",isError);}
  function getCurrentBrief(){const fd=new FormData(websiteForm);return {projectName:String(fd.get("projectName")||"").trim(),businessType:String(fd.get("businessType")||"").trim(),designStyle:String(fd.get("designStyle")||"Modern premium"),description:String(fd.get("description")||"").trim(),features:String(fd.get("features")||"").trim(),brandColor:String(fd.get("brandColor")||"Choose a suitable palette"),pageCount:String(fd.get("pageCount")||"One-page landing website")};}
  function validFiles(files){return files&&typeof files.html==="string"&&typeof files.css==="string"&&typeof files.js==="string"&&files.html.length<180000&&files.css.length<180000&&files.js.length<180000;}
  function makePreviewDocument(files){
    // Preview runs in a sandboxed iframe without same-origin access. External network requests are restricted.
    const safeCss=files.css.replace(/<\/style/gi,"<\\/style");
    const safeJs=files.js.replace(/<\/script/gi,"<\\/script");
    let html=files.html;
    const csp='<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data: https:; style-src \'unsafe-inline\' https:; font-src https: data:; script-src \'unsafe-inline\' https:; connect-src \'none\'; form-action \'none\'; base-uri \'none\'">';
    if(/<head[^>]*>/i.test(html)) html=html.replace(/<head([^>]*)>/i,`<head$1>${csp}<style>${safeCss}</style>`); else html=`<!doctype html><html><head>${csp}<style>${safeCss}</style></head><body>${html}</body></html>`;
    if(/<\/body>/i.test(html)) html=html.replace(/<\/body>/i,`<script>${safeJs}<\/script></body>`); else html+=`<script>${safeJs}<\/script>`;
    return html;
  }
  function showPreview(){if(!generatedFiles)return;preview.srcdoc=makePreviewDocument(generatedFiles);preview.hidden=false;previewEmpty.hidden=true;previewWrap.classList.toggle("mobile-preview",previewMode==="mobile");previewStatus.textContent=`Preview ready · ${previewMode}`;}
  function renderFile(){if(!generatedFiles){codeView.textContent="Generated source code will appear here.";return;}codeView.textContent=generatedFiles[activeFile];$$('.file-tab').forEach(tab=>{const active=tab.dataset.file===activeFile;tab.classList.toggle("active",active);tab.setAttribute("aria-selected",String(active));});}
  function setGeneratedFiles(files){if(!validFiles(files))throw new Error("The AI response did not contain all three valid website files (HTML, CSS, and JavaScript).");generatedFiles={html:files.html,css:files.css,js:files.js};fileState.textContent="FILES READY";saveButton.disabled=false;$("#copyFileButton").disabled=false;$("#downloadFileButton").disabled=false;$("#downloadAllButton").disabled=false;renderFile();showPreview();$("#settingsWebsiteStatus").textContent="Generation response received; review the preview and test the exported files.";}
  async function generateWebsite(event){event.preventDefault();if(websiteBusy)return;const brief=getCurrentBrief();if(!brief.projectName||!brief.businessType||!brief.description){setWebsiteFeedback("Please enter a project name, choose a business type, and describe the website.",true);return;}websiteBusy=true;generateButton.disabled=true;generateButton.textContent="Generating…";setWebsiteFeedback("Sending your brief to the secure website-generation API. This can take a little time.");$("#settingsWebsiteStatus").textContent="Generation request in progress.";
    try{const response=await fetch("/api/website",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"generate",brief})});let data;try{data=await response.json();}catch{throw new Error(response.ok?"The website API returned invalid JSON.":`Website API returned HTTP ${response.status}.`);}if(!response.ok||data.success===false)throw new Error(data.error||`Website generation failed (HTTP ${response.status}).`);setGeneratedFiles(data.files);setWebsiteFeedback("Website files generated. Review the preview carefully before using them for a client.");$("#previewTitle").textContent=brief.projectName;}
    catch(error){const message=error instanceof TypeError?"Could not reach /api/website. Confirm the new API file is deployed to Vercel.":error.message||"Generation failed.";setWebsiteFeedback(message,true);$("#settingsWebsiteStatus").textContent=`Not ready: ${message}`;}
    finally{websiteBusy=false;generateButton.disabled=false;generateButton.innerHTML='Generate website <span>✦</span>';}}
  function downloadText(filename,text,mime="text/plain;charset=utf-8"){const blob=new Blob([text],{type:mime});const url=URL.createObjectURL(blob);const link=document.createElement("a");link.href=url;link.download=filename;document.body.appendChild(link);link.click();link.remove();URL.revokeObjectURL(url);}
  function safeFilename(name){return name.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,50)||"joseph-ai-website";}
  function downloadCurrentFile(){if(!generatedFiles)return;downloadText(fileNames[activeFile],generatedFiles[activeFile],activeFile==="html"?"text/html;charset=utf-8":"text/plain;charset=utf-8");}
  function downloadAllFiles(){if(!generatedFiles)return;const base=safeFilename(getCurrentBrief().projectName);for(const key of ["html","css","js"])downloadText(`${base}-${fileNames[key]}`,generatedFiles[key],key==="html"?"text/html;charset=utf-8":"text/plain;charset=utf-8");setWebsiteFeedback("Started three separate file downloads. Keep all three files together in one website folder.");}
  async function copyCurrentFile(){if(!generatedFiles)return;try{await navigator.clipboard.writeText(generatedFiles[activeFile]);setWebsiteFeedback(`${fileNames[activeFile]} copied to clipboard.`);}catch{setWebsiteFeedback("Clipboard access was blocked by the browser. Use Download file instead.",true);}}
  function readSavedProjects(){try{const value=JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]");return Array.isArray(value)?value.filter(item=>item&&typeof item.id==="string"&&typeof item.name==="string"&&validFiles(item.files)):[];}catch{return [];}}
  function renderSavedProjects(){const projects=readSavedProjects();savedProjects.replaceChildren();if(!projects.length){const empty=document.createElement("p");empty.className="empty-projects";empty.textContent="No saved projects yet.";savedProjects.appendChild(empty);return;}projects.forEach(project=>{const row=document.createElement("div");row.className="saved-project";const info=document.createElement("div");const name=document.createElement("strong");name.textContent=project.name;const date=document.createElement("small");date.textContent=`Saved ${new Date(project.savedAt).toLocaleString()}`;info.append(name,date);const actions=document.createElement("div");actions.className="saved-project-actions";const load=document.createElement("button");load.type="button";load.textContent="Load";load.addEventListener("click",()=>{generatedFiles={...project.files};$("#projectName").value=project.name;fileState.textContent="FILES READY";saveButton.disabled=false;$("#copyFileButton").disabled=false;$("#downloadFileButton").disabled=false;$("#downloadAllButton").disabled=false;renderFile();showPreview();setWebsiteFeedback(`Loaded ${project.name} from this device.`);});const remove=document.createElement("button");remove.type="button";remove.textContent="Delete";remove.addEventListener("click",()=>{if(!window.confirm(`Delete the saved project “${project.name}” from this device?`))return;localStorage.setItem(STORAGE_KEY,JSON.stringify(readSavedProjects().filter(item=>item.id!==project.id)));renderSavedProjects();});actions.append(load,remove);row.append(info,actions);savedProjects.appendChild(row);});}
  function saveCurrentProject(){if(!generatedFiles)return;const brief=getCurrentBrief();const projects=readSavedProjects();const item={id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,name:brief.projectName||"Untitled website",brief,files:generatedFiles,savedAt:new Date().toISOString()};try{const next=[item,...projects.filter(p=>p.name!==item.name)].slice(0,15);localStorage.setItem(STORAGE_KEY,JSON.stringify(next));renderSavedProjects();setWebsiteFeedback("Project saved in this browser. It is not backed up online.");}catch{setWebsiteFeedback("Could not save this project. Browser storage may be full or disabled. Download the files as a backup.",true);}}
  websiteForm.addEventListener("submit",generateWebsite);
  $("#resetWebsiteButton").addEventListener("click",()=>{websiteForm.reset();setWebsiteFeedback("Brief cleared.");});
  $$(".file-tab").forEach(tab=>tab.addEventListener("click",()=>{activeFile=tab.dataset.file;renderFile();}));
  $$(".device-button").forEach(button=>button.addEventListener("click",()=>{previewMode=button.dataset.preview;$$('.device-button').forEach(item=>{const active=item===button;item.classList.toggle("active",active);item.setAttribute("aria-pressed",String(active));});if(generatedFiles)showPreview();else previewWrap.classList.toggle("mobile-preview",previewMode==="mobile");}));
  $("#copyFileButton").addEventListener("click",copyCurrentFile);$("#downloadFileButton").addEventListener("click",downloadCurrentFile);$("#downloadAllButton").addEventListener("click",downloadAllFiles);saveButton.addEventListener("click",saveCurrentProject);renderSavedProjects();

  $$(".nav-link").forEach(button=>button.addEventListener("click",()=>openPage(button.dataset.page)));
  $$('[data-open-page]').forEach(button=>button.addEventListener("click",()=>openPage(button.dataset.openPage)));
  menuButton.addEventListener("click",()=>{const isOpen=sidebar.classList.toggle("open");menuButton.setAttribute("aria-expanded",String(isOpen));});
  document.addEventListener("keydown",event=>{if(event.key==="Escape"){sidebar.classList.remove("open");menuButton.setAttribute("aria-expanded","false");}});
  brainForm.addEventListener("submit",async event=>{event.preventDefault();const message=brainInput.value.trim();if(!message){brainFeedback.textContent="Please enter a message first.";return;}brainInput.value="";await sendBrainMessage(message);});
  window.addEventListener("hashchange",()=>{const page=window.location.hash.slice(1);if(pageTitles[page])openPage(page);});
  const initialPage=window.location.hash.slice(1);openPage(pageTitles[initialPage]?initialPage:"dashboard");
  console.info("Joseph AI V2 interface initialized.");
})();
