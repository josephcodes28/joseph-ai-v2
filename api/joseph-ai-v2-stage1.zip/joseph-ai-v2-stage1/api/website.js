"use strict";

const MAX_BRIEF_LENGTH = 6000;
const MAX_OUTPUT_TOKENS = 12000;

function send(res, status, body) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  return res.end(JSON.stringify(body));
}

function extractJson(text) {
  const cleaned = String(text || "").trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  try { return JSON.parse(cleaned); } catch {}
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start, end + 1));
  throw new Error("The AI returned content that was not valid JSON. Please try again.");
}

function validateFiles(files) {
  if (!files || typeof files !== "object") return false;
  return ["html", "css", "js"].every((key) => typeof files[key] === "string" && files[key].trim().length > 0 && files[key].length <= 180000);
}

function buildPrompt(brief) {
  return `You are a senior frontend engineer and conversion-focused web designer. Generate a polished, responsive, real frontend website for the following client brief.\n\nPROJECT: ${brief.projectName}\nBUSINESS TYPE: ${brief.businessType}\nDESIGN DIRECTION: ${brief.designStyle}\nBRAND COLOUR: ${brief.brandColor}\nWEBSITE SIZE: ${brief.pageCount}\nDESCRIPTION: ${brief.description}\nREQUESTED FEATURES: ${brief.features || "Choose useful, realistic sections for this business."}\n\nREQUIREMENTS:\n1. Return exactly three complete files: html, css, and js. Return JSON only, with keys html, css, js. No markdown fences or commentary.\n2. HTML must be a complete valid document with semantic sections, accessible labels, useful metadata, and all content written for this business.\n3. CSS must be complete, original, visually polished, responsive for phones/tablets/desktops, and include strong spacing, typography, hierarchy, hover/focus states, and a coherent palette. Avoid generic unstyled layouts.\n4. JavaScript must be plain browser JavaScript, no build tools or package imports. Wire every visible interactive control. Do not create fake checkout, fake account security, fake database, fake payment, or fake booking confirmation. If a requested feature needs a server, implement a clearly labelled frontend inquiry/request form that validates input and explains it is a demo until a backend is connected.\n5. Do not claim certifications, awards, customer counts, testimonials, addresses, phone numbers, prices, or business facts that were not supplied. Use clearly editable neutral placeholder copy where business facts are missing. Never invent contact details.\n6. Use inline SVG only when useful. Avoid dependency on remote images; if images are necessary, use attractive CSS gradients or safe placeholder blocks with descriptive alt text.\n7. Do not include external scripts, tracking, analytics, iframes, forms that submit to third parties, or code that sends visitor data anywhere.\n8. Keep HTML/CSS/JS internally consistent. Use IDs and selectors that actually exist. The site must work by opening index.html locally.\n9. Include a clear header/navigation, high-quality hero, relevant business sections, meaningful call to action, and footer. Make the first viewport especially professional.\n10. Return concise but complete code; avoid truncation.\n\nJSON SHAPE: {"html":"complete HTML document","css":"complete CSS stylesheet","js":"complete JavaScript"}`;
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return send(res, 405, { success: false, error: "Method not allowed. Use POST." });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return send(res, 503, { success: false, error: "GEMINI_API_KEY is not configured in this Vercel project. Add it as a server-side environment variable and redeploy." });

  const body = req.body && typeof req.body === "object" ? req.body : {};
  const brief = body.brief && typeof body.brief === "object" ? body.brief : {};
  const required = ["projectName", "businessType", "description"];
  for (const key of required) {
    if (typeof brief[key] !== "string" || !brief[key].trim()) return send(res, 400, { success: false, error: `Please provide ${key} in the website brief.` });
  }
  const briefText = JSON.stringify(brief);
  if (briefText.length > MAX_BRIEF_LENGTH) return send(res, 413, { success: false, error: "The website brief is too long. Shorten the description or feature list and try again." });

  const model = (process.env.GEMINI_MODEL || "gemini-3.5-flash-lite").trim();
  const prompt = buildPrompt(brief);
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 110000);

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.65, maxOutputTokens: MAX_OUTPUT_TOKENS, responseMimeType: "application/json" }
      })
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const providerMessage = payload?.error?.message;
      const safeMessage = typeof providerMessage === "string" ? providerMessage.slice(0, 500) : `Gemini returned HTTP ${response.status}.`;
      return send(res, response.status === 429 ? 429 : 502, { success: false, error: `Gemini generation failed: ${safeMessage}` });
    }

    const candidate = payload?.candidates?.[0];
    const text = candidate?.content?.parts?.map((part) => part.text || "").join("\n");
    if (!text) {
      const reason = candidate?.finishReason || "No text was returned";
      return send(res, 502, { success: false, error: `Gemini did not return website code (${reason}). Try a shorter brief.` });
    }

    let files;
    try { files = extractJson(text); }
    catch (error) { return send(res, 502, { success: false, error: error.message }); }
    if (!validateFiles(files)) return send(res, 502, { success: false, error: "Gemini's response was incomplete. It must contain non-empty html, css, and js files. Please try again with a shorter brief." });

    return send(res, 200, { success: true, files: { html: files.html, css: files.css, js: files.js }, model, note: "Frontend files generated. Backend-dependent features are not connected by this endpoint." });
  } catch (error) {
    const message = error?.name === "AbortError" ? "The generation request timed out. Try a shorter brief or check the Gemini model availability." : "Could not contact the Gemini service. Check the Vercel function logs and network configuration.";
    return send(res, 504, { success: false, error: message });
  } finally {
    clearTimeout(timeout);
  }
};
